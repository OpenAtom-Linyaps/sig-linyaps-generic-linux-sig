# 玲珑网页版安装器

玲珑网页版安装器 (linyaps-web-store-installer) 是一款用于[如意玲珑应用商店](https://store.linyaps.org.cn/)的网页安装程序。

## 获取支持

如果您在使用时遇到任何问题，请通过如下几个方式与我们取得联系：

- [Gitter](https://gitter.im/orgs/linuxdeepin/rooms)
- [IRC 频道](https://webchat.freenode.net/?channels=deepin)
- [论坛](https://bbs.deepin.org)
- [Wiki](https://wiki.deepin.org/)

## 参与开发

我们时刻欢迎您参与开发和报告问题：

- [开发者代码贡献指南](https://github.com/linuxdeepin/developer-center/wiki/Contribution-Guidelines-for-Developers) (中文)
- [Contribution guide for developers](https://github.com/linuxdeepin/developer-center/wiki/Contribution-Guidelines-for-Developers-en) (English)

## 许可证

本项目使用 [LGPL-3.0-or-later](LICENSE) 许可授权。
